import PickOne from '@/app/comp/PickOne'
import React from 'react'

function page() {
    return (
        <PickOne/>
    )
}

export default page