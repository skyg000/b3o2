"use client"
import React, { useEffect } from 'react'
import Join from '../../comp/Join'
import pageSt from '../../page.module.css'
function page() {
  
  return (
    <Join/>
  )
}

export default page