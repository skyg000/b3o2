import React from "react";
import Checkfortune from "../../comp/Checkfortune";
function page() {
  return (
    <>
      <Checkfortune />
    </>
  );
}

export default page;
