"use client"
import React from 'react'

function Matchlist() {
    return (
        <div>Matchlist</div>
    )
}

export default Matchlist