"use client"
import React from 'react'

function Checkfortune() {
    return (
        <div>Checkfortune</div>
    )
}

export default Checkfortune