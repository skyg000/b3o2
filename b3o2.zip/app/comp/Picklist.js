"use client"
import React from 'react'

function picklist() {
    return (
        <div>picklist</div>
    )
}

export default picklist