"use client"
import React from 'react'

function Join() {
    return (
        <div>Join</div>
    )
}

export default Join