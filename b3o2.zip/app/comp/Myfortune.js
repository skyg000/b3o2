"use client"
import React from 'react'

function Myfortune() {
    return (
        <div>Myfortune</div>
    )
}

export default Myfortune