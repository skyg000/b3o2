import styles from './page.module.css'
import './globals.css'

import Login from './comp/Login'
export default function Home() {
  return(
    <>
      <Login/>
    </>
  )
}


