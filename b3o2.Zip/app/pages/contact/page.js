import React from 'react'
import Contact from '../../comp/Contact'
function page() {
    return (
        <Contact/>
    )
}

export default page