import Write from "../../comp/Write"
function page() {
    return (
        <>
          <Write/>
        </>
    )
}

export default page