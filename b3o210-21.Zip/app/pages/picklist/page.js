import React from 'react'
import Picklist from '../../comp/Picklist'
function page() {
  return (
    <Picklist/>
  )
}

export default page