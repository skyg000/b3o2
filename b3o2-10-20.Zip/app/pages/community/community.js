import React from 'react'
import Community from '@/app/comp/Community'
function community() {
  return (
    <Community/>
   
  )
}

export default community