import Matchlist from '../../comp/Matchlist'
import React from 'react'

function page() {
  return (
    <Matchlist/>
  )
}

export default page